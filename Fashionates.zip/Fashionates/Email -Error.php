<?php
session_start();
echo '<h2>Email address already exists</h2>';
$_SESSION['']
?>
<br />
<a href="register.php" >Please click here to go back to registration page</a>
