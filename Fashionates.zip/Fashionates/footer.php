<div id="all">

    <!-- *** ADVANTAGES ***
_________________________________________________________ -->

    <div id="advantages">

        <div class="container">
            <div class="col-md-12">
            </div>
        </div>
        <!-- /.container -->

    </div>
    <!-- /#advantages -->

    <div id="copyright">
        <div class="container">
            <div class="col-md-12">
                <p class="pull-left">&copy; Trishul.</p>
                <p class="pull-right">
                    <img src="img/payment.png" alt="payments accepted">
                </p>

            </div>
        </div>
    </div>
</div>
<!-- /#all -->
